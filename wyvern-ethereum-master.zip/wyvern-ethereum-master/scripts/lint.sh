#!/bin/sh

./node_modules/solium/bin/solium.js -d ./contracts --fix

exit 0
