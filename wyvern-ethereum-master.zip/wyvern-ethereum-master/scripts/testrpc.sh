#!/bin/sh

testrpc --networkId 50 --port 8545
