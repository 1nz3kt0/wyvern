#!/bin/sh

node node_modules/@digix/doxity/lib/bin/doxity.js develop
