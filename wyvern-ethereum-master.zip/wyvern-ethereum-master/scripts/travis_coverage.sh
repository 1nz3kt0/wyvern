#!/usr/bin/env bash

yarn coverage
sleep 1
exit 0
