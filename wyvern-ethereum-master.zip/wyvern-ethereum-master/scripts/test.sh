#!/bin/sh

rm -rf build
truffle test $1
